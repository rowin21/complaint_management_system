<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="css/navigation_user.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <?php
        include 'userHeader.html';
        include '../config.php';
    ?>
    <div class="actionContainer">
        <div class="navigation">
            <ul>
                <li data-li="Account" class="nav_btn">Account</li>
                <li data-li="RegisterComplaint" class="nav_btn">Register Complaint</li>
                <li data-li="Track" class="nav_btn">Track Status</li>
                <li data-li="View" class="nav_btn">View Report</li>
                <li data-li="ChangePassword" class="nav_btn">Change Password</li>
            </ul>
        </div>
        <div class="action">
            <div class="dash">
                <?php
                date_default_timezone_set('Asia/Calcutta');
                $Hour = date('G');

                if ( $Hour >= 5 && $Hour <= 11 ) {
                    echo "<p>Good Morning,</p>";
                } else if ( $Hour >= 12 && $Hour <= 14 ) {
                    echo "<p>Good Afternoon,</p>";
                } else if ( $Hour >= 15 || $Hour <= 4 ) {
                    echo "<p>Good Evening,</p>";
                }
                $dt = new DateTime(); 
                echo "<p> It's ".$dt->format('l')." today.</p>"; 
                ?>
            </div>
            <div class="tab Account">
                <div class="actionHeading">Profile</div>
                <div class="form">
                <?php

                    $sql = "select * from userdata where email='niharikamayya@gmail.com' ";
                    $result = mysqli_query($conn,$sql);
                    $val = $result->fetch_assoc();
                    //print_r($val);
                ?>
                <div class="profileHead"><?php echo "Welcome " . $val["first_name"] ." ". $val['last_name'] ?></div>
                <div class="profile"><?php echo " on: ". $val["update_date"]?></div>
                <table class="profile_table">
                    <tr>
                        <td>User ID :<?php echo $val["user_id"]?></td>
                        <td>Name :<?php echo $val["first_name"] ." ". $val['last_name']?></td>
                    </tr>
                    <tr>
                        <td>Phone: <?php echo $val["phone"]?></td>
                        <td>Email :<?php echo $val["email"]?></td>
                    </tr>
                    <tr>
                        <td>Street :<?php echo $val["street"]?></td>
                        <td>District :<?php echo $val["district"]?></td>
                    </tr>
                    <tr>
                        <td>Pincode :<?php echo $val["pin_code"]?></td>
                    </tr>
                </table>
                </div>
            </div>
        </div>
    <?php
        include 'userFooter.html';
    ?>
    <script src="js/navbarDisplay.js"></script>
</body>
</html>